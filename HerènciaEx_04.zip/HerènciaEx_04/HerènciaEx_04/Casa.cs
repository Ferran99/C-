﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HerènciaEx_04
{
    class Casa
    {
    }
}
