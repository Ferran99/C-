﻿using System;

namespace UF1.Persistència_en_fitxers
{
    class Program
    {
        static void Main(string[] args)
        {
            AbstractTool.vComprovaDirectori();
        }
    }
}
